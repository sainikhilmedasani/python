from pokemon_analysis import data
from collections import Counter
from collections import defaultdict

def generation_types(s):
    generation_counts=[]
    a=data.get_data()
    for p in a:
        if p['primary_type'] in generation_counts:
            if(p['generation']==s):
                generation_counts.append((p['primary_type']))
        else:
            if(p['generation']==s):
                generation_counts.append((p['primary_type']))
    return Counter((generation_counts))

def generation_ranges(s):
    a=data.get_data()
    minv=a[0]['hp']
    mina=a[0]['attack']
    mind=a[0]['defense']
    for i in range(1,len(a)):
        if(a[i]['generation']==s):
            if(minv>a[i]['hp']):
                minv=a[i]['hp']
            if(mina>a[i]['attack']):
                mina=a[i]['attack']
            if(mind>a[i]['defense']):
                mind=a[i]['defense']
            
    
    maxv=a[0]['hp']
    maxa=a[0]['attack']
    maxd=a[0]['defense']
    for i in range(1,len(a)):
        if(a[i]['generation']==s):
            if(maxv<a[i]['hp']):
                maxv=a[i]['hp']
            if(maxa<a[i]['attack']):
                maxa=a[i]['attack']
            if(maxd<a[i]['defense']):
                maxd=a[i]['defense']
    
    final_val = {'hp' : (minv,maxv),'attack': (mina,maxa),'defence':(mind,maxd)}
    return final_val

