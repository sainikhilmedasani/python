'''Name : sai nikhil Medasani
Zid: Z1909575'''
import sys
from pokemon_analysis import data
from pokemon_analysis import generation
from pokemon_analysis import compare

get1=data.get_data()

if(len(sys.argv)==3 and sys.argv[1]=='generation'):
    b=int(sys.argv[2])
    a = generation.generation_ranges(b)
    print('Generation',str(b)+str(':'),'\n hp: ',str(list(a.values())[0][0]) + str('-') +str(list(a.values())[0][1]),
      '\n attack: ',str(list(a.values())[1][0]) + str('-') +str(list(a.values())[1][1]),
     '\n defense: ',str(list(a.values())[2][0]) + str('-') +str(list(a.values())[2][1]))
elif(len(sys.argv)>=4):
    if (sys.argv[1]=='generation' and sys.argv[3]=='types'):
        print(generation.generation_types(int(sys.argv[2])))
    elif (sys.argv[1]=='compare'):
        l=len(sys.argv)
        for x in range(2,l-1):
            for y in range(x+1,l):
                a=sys.argv[x]
                b=sys.argv[y]
                c= compare.combat_power_diff(a,b)
                trim='{:.6f}'.format(c)
                if(str(trim)[0]=='-'):
                    print(a,'has',trim,'combat power than',b)
                else:
                    print(a,'has',str('+') + str(trim),'combat power than',b)
    elif (sys.argv[1]=='compare_attk'):
        print(compare.attack_diff(sys.argv[2],sys.argv[3]))
    elif (sys.argv[1]=='compare_defense'):
        print(compare.defense_diff(sys.argv[2],sys.argv[3]))
    elif (sys.argv[1]=='compare_hp'):
        print(compare.hp_diff(sys.argv[2],sys.argv[3]))
    
else:
    print('Usage: python -m pokemon_analysis [generation <num> | compare <name1> <name2>]')