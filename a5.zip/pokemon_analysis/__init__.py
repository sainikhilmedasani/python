'''Name : sai nikhil Medasani
Zid: Z1909575'''
from pokemon_analysis import data
from pokemon_analysis import generation
from pokemon_analysis import compare