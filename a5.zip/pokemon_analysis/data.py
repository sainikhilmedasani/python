import os
import json
data=None
def get_data():
    global data
    if(data!=None):
        return data
    else:
        new_pokemon = os.path.join(os.path.dirname("local_fname"),'pokemom.json')
        data = json.load(open(new_pokemon))
        return data
