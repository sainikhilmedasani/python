from pokemon_analysis import data
def call_combat(newcom):
    get=data.get_data()
    for i in get:
        if(i['name']==newcom):
            Attack = 2 * round((i['attack']**0.5) * (i['sp_attack']**0.5) + (i['speed']**0.5))
            Defense = 2 * round((i['defense']**0.5) * (i['sp_defense']**0.5) + (i['speed']**0.5))
            Stamina = 2 * i['hp']
            MaxCP = ((Attack + 15) * ((Defense + 15)**0.5) * ((Stamina + 15)**0.5) * (0.7903001**2)) / 10
            return MaxCP
            
def diff_cal(d1,d2):
    d3=d1 - d2
    return d3

def find_value(new1,new):
    a=data.get_data()
    for i in a:
        if(i['name']==new):
            first_attck=i[new1]
            return first_attck

def attack_diff(name1,name2):
    a=find_value('attack',name1)
    b=find_value('attack',name2)
    diff1=diff_cal(a,b)
    return diff1
        
def defense_diff(name3,name4):
    c=find_value('defense',name3)
    d=find_value('defense',name4)
    diff2=diff_cal(c,d)
    return diff2

def hp_diff(name5,name6):
    h=find_value('hp',name5)
    i=find_value('hp',name6)
    diff3=diff_cal(h,i)
    return diff3

def combat_power_diff(name7,name8):
    cb1=call_combat(name7)
    cb2=call_combat(name8)
    diff4=diff_cal(cb1,cb2)
    return diff4
    


